
export default class AboutPage extends React.Component {

    render() {
        return (
            <div>
                <h1>Tech Behind Premier Bank</h1>
                <hr />
                <p>It is build with the most modern technologies and provides the best user experience ever</p>
                <ul>
                    <li>React, React Router</li>
                    <li>ES6 JavaScript and BootStrap for Styling</li>
                    <li>Ja*</li>
                </ul>
            </div>
        );
    }
}